# ALEX: compilador de mi lenguaje de programación (escrito en C)

Proyecto de la materia **Compiladores** (Universidad Adventista de Centro América, Escuela de Ingeniería).
Profesor: William Martinez · Estudiante: Alexis Viquez Terranova

ALEX es un lenguaje con palabras en español, pensado para que el código sea fácil de leer.
Este repositorio contiene el compilador (análisis léxico, sintáctico y semántico) y un intérprete que ejecuta el programa. Todo está escrito en **C** y vive en un solo archivo: `alex.c`.
El lenguaje tiene variables, expresiones, **condicionales** (`si` / `sino`), **funciones** (predefinidas y propias) y **arreglos** (`entero[]`, `texto[]`, ...).

## Entregables

| Entregable | Dónde está en `alex.c` |
|---|---|
| Analizador léxico | `analizar_lexico()` |
| Analizador sintáctico | `programa()`, `sentencia()`, `declaracion()`, `expresion()`, `suma()`, `termino()`, `factor()` (descendente recursivo) |
| Analizador semántico | `sem_sentencia()`, `sem_declaracion()`, `sem_llamada()`, `sem_tipo()` (la función `tipo_expr_esp()` calcula el tipo de cada expresión) |
| AST Table | `numerar()` y la sección "AST TABLE" de la salida |
| Tabla de símbolos | `struct Simbolo`, `struct Ambito` y la sección "TABLA DE SÍMBOLOS" de la salida (con ámbitos y tabla de funciones) |
| Funciones | Parser (`funcion()`, `retorno()`, `llamada()`), Semántico (`sem_funcion()`, `sem_retorno()`, `sem_llamada()`), ejecución (`llamar()`) |
| Condicionales | Parser (`si()`, `bloque()`), Semántico (`sem_si()`, `sem_bloque()`), ejecución (`exec_stmt()`, `ejecutar_bloque()`) |
| Arreglos | Léxico (`[` y `]`), Parser (`parse_tipo()`, `factor()`, `postfijo()`, `asignacion()`), Semántico (casos `N_LISTA` e `N_INDICE` de `sem_tipo()`, `sem_asig_indice()`), ejecución (`struct Lista`, `evaluar()`, `llamar_predef()`) |

## Requisitos

Un compilador de C (`gcc`) y `make`. No usa ninguna librería externa, solo la librería estándar de C y la de matemáticas.
En Ubuntu: `sudo apt install build-essential`.

## Cómo compilarlo y ejecutarlo

```
make                                       (compila y deja el ejecutable ./alex)
./alex ejemplos/ok.alex
./alex ejemplos/funciones.alex
./alex ejemplos/condicionales.alex
./alex ejemplos/arreglos.alex
./alex ejemplos/arreglos_metodos.alex
./alex ejemplos/ejemplo_arrays_profesor.alex
./alex ejemplos/mas_funciones.alex
./alex ejemplos/ejemplo_profesor.alex   (el ejemplo del profesor, func add / func log, escrito en ALEX)
./alex ejemplos/ejemplo_if_profesor.alex   (los ejemplos de if del profesor, escritos en ALEX)
./alex ejemplos/logico_o.alex           (operador «o» y comparaciones con palabras)
./alex ejemplos/condicionales.alex --tokens
make probar                                (corre todos los ejemplos y comprueba el resultado esperado)
```

Si no tienes `make`: `gcc -Wall -Wextra -O2 -o alex alex.c -lm`.

En Windows (PowerShell) no hay `make`, pero con `gcc` instalado (por ejemplo con MSYS2) se compila y se corre así:

```
gcc -Wall -Wextra -O2 -o alex.exe alex.c -lm
.\alex.exe ejemplos\ok.alex
.\alex.exe ejemplos\arreglos.alex --tokens
```

Programas de ejemplo con errores, uno por tipo:

```
./alex ejemplos/err_lexico.alex
./alex ejemplos/err_sintactico.alex
./alex ejemplos/err_semantico.alex
./alex ejemplos/err_func_sintactico.alex
./alex ejemplos/err_func_semantico.alex
./alex ejemplos/err_si_sintactico.alex
./alex ejemplos/err_si_semantico.alex
./alex ejemplos/err_arr_sintactico.alex
./alex ejemplos/err_arr_semantico.alex
./alex ejemplos/err_arr_ejecucion.alex     (índice fuera de rango, error al ejecutar)
./alex ejemplos/err_arr_metodo.alex         (método desconocido)
./alex ejemplos/err_arr_metodo_tipo.alex    (tipos incorrectos en métodos)
./alex ejemplos/err_arr_vacio.alex         (quitar de un arreglo vacío, error al ejecutar)
./alex ejemplos/err_funciones_pred.alex    (errores de tipo al usar las funciones predefinidas)
./alex ejemplos/err_raiz.alex              (raíz de un número negativo, error al ejecutar)
./alex ejemplos/err_logico_semantico.alex  (errores de tipo con «o» y las palabras)
./alex ejemplos/err_logico_sintactico.alex (errores sintácticos con «o» y las palabras)
```

## Reglas del lenguaje

| Regla | Detalle |
|---|---|
| Declarar | `dato nombre: tipo;` o `dato nombre: tipo = valor;` |
| Asignar | `nombre = expresion;` (la variable debe estar declarada) |
| Fin de instrucción | Siempre `;` |
| Tipos | `entero`, `decimal`, `texto`, `logico` y sus arreglos: `entero[]`, `decimal[]`, `texto[]`, `logico[]` |
| Valores lógicos | `verdadero` y `falso` |
| Nombres | Empiezan con letra o `_`; distinguen mayúsculas; aceptan acentos y ñ; no se repiten en el mismo ámbito |
| Palabras reservadas | dato, funcion, retornar, si, sino, entero, decimal, texto, logico, verdadero, falso |
| Valor por defecto | 0, 0.0, texto vacío, falso y arreglo vacío |
| Compatibilidad | Un entero cabe en un decimal; un decimal no cabe en un entero |
| Prohibido | Asignaciones encadenadas (`a = b = 3;`) |
| Operadores aritméticos | `+ - * /` y paréntesis; `+` también une textos |
| Comparaciones | `==  !=  <  >  <=  >=`; el resultado siempre es `logico` |
| Operador lógico | `a o b` (también `a || b`): verdadero si alguno de los dos lo es; los dos lados deben ser `logico` |
| Comentarios | `// hasta el final de la línea` |

### Comparaciones

| Operador | Qué compara | Ejemplo |
|---|---|---|
| `<  >  <=  >=` | Solo números (entero o decimal, se pueden mezclar) | `edad >= 18` |
| `==  !=` | Dos números, dos textos o dos lógicos (los arreglos no se comparan) | `nombre == "Ana"` |

Una comparación tiene menos prioridad que la suma y la resta: `a + 1 > b * 2` se calcula como `(a + 1) > (b * 2)`.
No se pueden comparar tipos distintos (por ejemplo, un texto con un entero).

Las comparaciones también se pueden escribir con palabras:

| Palabra | Equivale a | Ejemplo |
|---|---|---|
| `es` | `==` | `nombre es "Ana"` |
| `no es` | `!=` | `nombre no es "Pedro"` |
| `mayor` | `>` | `edad mayor 18` |
| `menor` | `<` | `edad menor 18` |

Esas palabras no son reservadas: solo funcionan como operador cuando van entre dos valores, así que los nombres `mayor` o `menor` se pueden seguir usando para variables y funciones.

### Operador lógico «o»

```
si (edad < 12 o edad > 65) {
    mostrar("Entrada con descuento");
}
```

| Regla | Detalle |
|---|---|
| Forma | `a o b` o `a || b`; se pueden encadenar: `a o b o c` |
| Tipos | Los dos lados deben ser `logico` (normalmente comparaciones); el resultado es `logico` |
| Prioridad | La más baja: primero se calculan las operaciones y las comparaciones, y al final el `o` (`a > 1 o b > 2` es `(a > 1) o (b > 2)`) |
| Cortocircuito | Si el lado izquierdo ya es verdadero, el derecho no se calcula (por ejemplo, no se llama la función que está ahí) |

### Condicionales

```
si (edad >= 18) {
    mostrar("Es mayor de edad");
} sino si (edad >= 12) {
    mostrar("Es adolescente");
} sino {
    mostrar("Es menor de edad");
}
```

| Regla | Detalle |
|---|---|
| Forma | `si (condicion) { ... }` y, opcionalmente, `sino { ... }` o `sino si (condicion) { ... }` |
| Paréntesis y llaves | Obligatorios: la condición va entre `( )` y cada bloque entre `{ }` |
| Condición | Debe ser de tipo `logico` (normalmente una comparación) |
| Ejecución | Se evalúa la condición; si es verdadera corre el bloque del `si`, si no, el del `sino` (si existe) |
| Ámbito de bloque | Una variable declarada dentro de un bloque solo existe en ese bloque |
| Visibilidad | Un bloque ve las variables de los bloques que lo rodean y puede modificarlas |
| Sombreado | Un bloque puede declarar una variable con el nombre de una externa: la del bloque la tapa solo dentro del bloque |
| Dónde | Se puede usar al nivel principal y dentro de funciones; no se pueden definir funciones dentro de un bloque |

### Funciones propias

```
funcion suma(a: entero, b: entero): entero {
    retornar a + b;
}

funcion saludar(quien: texto) {
    mostrar("Hola,", quien);
}

dato resultado: entero = suma(2, 3);
saludar("Alexis");
```

| Regla | Detalle |
|---|---|
| Definir | `funcion nombre(parametro: tipo, ...): tipo { ... }`; el tipo de retorno es opcional; los tipos pueden ser arreglos (`lista: entero[]`) |
| Retornar | `retornar valor;` termina la función y devuelve el valor; sin tipo de retorno no devuelve nada |
| Dónde | Solo al nivel principal; no se puede definir una función dentro de otra ni dentro de un bloque |
| Orden | Una función se define antes de llamarla |
| Llamar | `nombre(argumentos)`, como instrucción (`saludar("x");`) o dentro de una expresión (`suma(2, 3) * 2`) |
| Argumentos | Deben coincidir en cantidad y tipo con los parámetros (un entero sirve para un parámetro decimal) |
| Ámbito | Cada función tiene su propio ámbito: ve sus parámetros y sus variables locales, pero no las globales |
| Obligatorio | Si declara un tipo, debe tener `retornar` en todos sus caminos (por ejemplo, en el `si` y en el `sino`) y su valor debe ser de ese tipo |
| Prohibido | Código después de un `retornar` que siempre se ejecuta; usar una función sin valor dentro de una expresión |
| Recursión | Una función puede llamarse a sí misma; el `si` sirve de caso base (límite de 200 llamadas anidadas) |

### Arreglos

```
dato notas: decimal[] = [8.5, 9, 7.25];
dato nombres: texto[] = ["Ana", "Luis"];
dato lista: entero[];                      // empieza vacío

dato primera: decimal = notas[0];          // el primer elemento es el 0
notas[1] = 10;                             // cambiar un elemento
agregar(nombres, "Marta");                 // push: agrega al final
dato ultimo: entero = quitar(lista);       // pop: saca el último y lo devuelve (si hay)
mostrar(longitud(nombres), notas);         // 3 [8.5, 10.0, 7.25]
```

| Regla | Detalle |
|---|---|
| Tipo | `tipo[]`: `entero[]`, `decimal[]`, `texto[]`, `logico[]`. Todos los elementos son del mismo tipo |
| Literal | `[a, b, c]` o `[]` (vacío). El literal toma el tipo de donde se guarda: `dato d: decimal[] = [1, 2];` guarda `[1.0, 2.0]` |
| Sin valor inicial | `dato lista: entero[];` empieza como arreglo vacío |
| Leer | `lista[i]`; `i` debe ser entero y empieza en 0 |
| Cambiar | `lista[i] = valor;` (el valor debe ser del tipo de los elementos) |
| `agregar(arreglo, valor)` o `arreglo.agregar(valor)` | Agrega un elemento al final (push) |
| `quitar(arreglo)` o `arreglo.quitar()` | Saca el último elemento y lo devuelve (pop) |
| `longitud(arreglo)` o `arreglo.longitud()` | Cantidad de elementos (`longitud` también sirve con texto) |
| Referencia | Un arreglo se pasa por referencia: si una función lo cambia, el original cambia; `b = a;` hace que ambos apunten al mismo arreglo |
| Compatibilidad | Un `entero[]` no cabe en un `decimal[]` (solo un literal como `[1, 2]` se adapta) |
| Prohibido | Arreglos dentro de arreglos, comparar arreglos con `==`, sumarlos |
| Errores al ejecutar | Índice fuera de rango y `quitar` de un arreglo vacío |

### Funciones predefinidas

| Función | Qué hace | Ejemplo |
|---|---|---|
| `mostrar(valor, ...)` | Imprime uno o más valores separados por espacio (un arreglo se imprime como `[1, 2, 3]`) | `mostrar("Total:", total);` |
| `longitud(texto o arreglo)` | Cantidad de caracteres o de elementos (entero) | `longitud("Alexis")` da 6 |
| `mayusculas(texto)` | Pasa el texto a mayúsculas | `mayusculas("hola")` da HOLA |
| `redondear(numero)` | Entero más cercano (los .5 suben) | `redondear(9.5)` da 10 |
| `absoluto(numero)` | Valor sin signo, del mismo tipo que el argumento | `absoluto(-15)` da 15 |
| `agregar(arreglo, valor)` | Agrega al final del arreglo (push) | `agregar(notas, 9.5);` |
| `quitar(arreglo)` o `arreglo.quitar()` | Saca el último elemento y lo devuelve (pop) | `quitar(notas)` |
| `minimo(a, b)` | El menor de dos números (entero si ambos son enteros, si no decimal) | `minimo(7, 12)` da 7 |
| `maximo(a, b)` | El mayor de dos números (mismo tipo que `minimo`) | `maximo(7, 3.5)` da 7.0 |
| `raiz(numero)` | Raíz cuadrada (decimal); error si el número es negativo | `raiz(81)` da 9.0 |
| `potencia(base, exponente)` | Base elevada al exponente (decimal) | `potencia(2, 10)` da 1024.0 |
| `minusculas(texto)` | Pasa el texto a minúsculas | `minusculas("HOLA")` da hola |
| `invertir(texto)` | Da vuelta el texto | `invertir("Rica")` da aciR |
| `contiene(texto, buscado)` | `verdadero` si el texto contiene lo buscado | `contiene("Costa Rica", "Rica")` da verdadero |
| `subtexto(texto, inicio, cantidad)` | Parte del texto; `inicio` cuenta desde 0 y si se pasa del final corta ahí | `subtexto("Costa Rica", 6, 4)` da Rica |
| `aTexto(valor)` | Convierte cualquier valor a texto, útil para unirlo con `+` | `"Edad: " + aTexto(edad)` |

No se puede definir una función ni una variable con el nombre de una predefinida.

## Gramática

```
programa    ::= { sentencia }
sentencia   ::= declaracion | asignacion | asig_indice | funcion | retorno | si | llamada ";"
declaracion ::= "dato" IDENT ":" tipo [ "=" expresion ] ";"
asignacion  ::= IDENT "=" expresion ";"
asig_indice ::= IDENT "[" expresion "]" "=" expresion ";"
funcion     ::= "funcion" IDENT "(" [ parametros ] ")" [ ":" tipo ] bloque
parametros  ::= IDENT ":" tipo { "," IDENT ":" tipo }
tipo        ::= TIPO [ "[" "]" ]
retorno     ::= "retornar" [ expresion ] ";"
si          ::= "si" "(" expresion ")" bloque [ "sino" ( si | bloque ) ]
bloque      ::= "{" { sentencia } "}"
metodo      ::= IDENT "." ("agregar" | "quitar" | "longitud") "(" [ expresion ] ")"
llamada     ::= IDENT "(" [ expresion { "," expresion } ] ")"
expresion   ::= comparacion { ("o" | "||") comparacion }
comparacion ::= suma { ("==" | "!=" | "<" | ">" | "<=" | ">=" | "es" | "no es" | "mayor" | "menor") suma }
suma        ::= termino { ("+" | "-") termino }
termino     ::= factor { ("*" | "/") factor }
factor      ::= "-" factor | ENTERO | DECIMAL | TEXTO | "verdadero" | "falso"
              | "[" [ expresion { "," expresion } ] "]"
              | ( llamada | IDENT | "(" expresion ")" ) { "[" expresion "]" }
```

## Fases del compilador

1. **Léxica:** convierte el texto en tokens.
2. **Sintáctica:** convierte los tokens en el árbol AST (parser descendente recursivo).
3. **Semántica:** llena la tabla de símbolos (por ámbito) y verifica declaraciones, duplicados, tipos, condiciones, argumentos, retornos e índices de arreglos.
4. **Ejecución:** recorre el AST y calcula el valor final de cada variable; cada llamada a una función y cada bloque crean su propio ámbito.

Si una fase encuentra errores, el compilador se detiene ahí y muestra cada error con su línea y columna.

## Detalles de la implementación en C

| Tema | Cómo lo resolví |
|---|---|
| Errores del parser | El parser usa `setjmp` / `longjmp`: al encontrar un error salta hasta el último punto seguro (`programa()` o `bloque()`), lo anota y sigue con la siguiente instrucción (modo pánico) |
| Árbol | Cada nodo es un `struct Nodo` con su clase (`N_DECL`, `N_SI`, ...), sus hijos, su línea y el tipo que llena el semántico |
| Tipos | Un tipo es un entero: 1 a 4 para `entero`, `decimal`, `texto` y `logico`; sumarle 8 lo vuelve arreglo (`entero[]`) |
| Valores en ejecución | `struct Valor` guarda una etiqueta (entero, decimal, texto, lógico, arreglo) y el dato; los arreglos son `struct Lista` que crece sola |
| Enteros | Son de 64 bits (`long long`); si una operación se pasa del rango, la ejecución se detiene con el error «Desbordamiento» en vez de dar un resultado equivocado |
| Acentos | El archivo se lee como UTF-8: las columnas, los anchos de tabla, `longitud` y `mayusculas` cuentan caracteres (no bytes), y los nombres pueden llevar acentos y ñ |
| Memoria | El programa es corto y termina enseguida, así que la memoria se reserva y se libera sola al salir el proceso |

## Estructura

```
alex.c           compilador e intérprete (un solo archivo)
Makefile         make, make probar, make limpiar
ejemplos/        programas de prueba (correctos y con errores)
GUIA.md          guía paso a paso del proyecto
PRESENTACION.md  guion de la presentación y conceptos de clase
```
